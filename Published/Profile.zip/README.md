# Mogadishu-Dataset
A vatSys Dataset for Mogadishu FIR on VATSIM.
